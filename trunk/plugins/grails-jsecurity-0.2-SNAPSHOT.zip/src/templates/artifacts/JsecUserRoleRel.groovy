class JsecUserRoleRel {
    JsecUser user
    JsecRole role
}
